package com.praveen.employee_attendance_tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeAttendanceTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
